-- New project only. Run in Supabase SQL Editor; do not execute on existing tables without migration.
create extension if not exists btree_gist;
create table if not exists public.schools (
 id bigint generated always as identity primary key,
 school_name text not null, office_code text not null, organization_code text not null unique,
 neis_school_code text, is_active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 school_id bigint references public.schools(id), login_id text unique,
 email text, role text not null check(role in ('super_admin','school_admin')),
 is_active boolean not null default true,
 check(role='super_admin' or school_id is not null)
);
create table if not exists public.booking_types (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id), name text not null,
 sort_order integer not null default 0, is_active boolean not null default true,
 unique(school_id,name), unique(school_id,id)
);
create table if not exists public.booking_resources (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id), type_id bigint not null,
 name text not null, description text, sort_order integer not null default 0,
 is_active boolean not null default true,
 foreign key(school_id,type_id) references public.booking_types(school_id,id),
 unique(school_id,id), unique(school_id,type_id,name)
);
create table if not exists public.booking_periods (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id), label text not null,
 start_time time not null, end_time time not null, sort_order integer not null default 0,
 is_active boolean not null default true,
 check(start_time<end_time), unique(school_id,id)
);
create table if not exists public.booking_regular_schedules (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id),
 resource_id bigint not null, period_id bigint not null,
 weekday smallint not null check(weekday between 0 and 6), -- JS weekday Sunday=0
 label text not null, valid_from date not null, valid_until date,
 check(valid_until is null or valid_from < valid_until),
 foreign key(school_id,resource_id) references public.booking_resources(school_id,id),
 foreign key(school_id,period_id) references public.booking_periods(school_id,id),
 exclude using gist(resource_id with =,period_id with =,weekday with =,
   daterange(valid_from,valid_until,'[)') with &&)
);
create table if not exists public.booking_reservations (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id),
 resource_id bigint not null, period_id bigint not null,
 reservation_date date not null, label text not null,
 status text not null default 'confirmed' check(status in ('pending','confirmed','cancelled')),
 created_by uuid references auth.users(id), created_at timestamptz not null default now(),
 foreign key(school_id,resource_id) references public.booking_resources(school_id,id),
 foreign key(school_id,period_id) references public.booking_periods(school_id,id)
);
create unique index if not exists booking_reserved_slot_unique
 on public.booking_reservations(resource_id,reservation_date,period_id)
 where status in ('pending','confirmed');
-- Daily plan categories: history-safe, half-open validity interval
create table if not exists public.daily_categories (
 id bigint generated always as identity primary key, school_id bigint not null references public.schools(id),
 category_code text not null, unique(school_id,category_code), unique(school_id,id)
);
create table if not exists public.daily_category_versions (
 id bigint generated always as identity primary key,
 school_id bigint not null, category_id bigint not null,
 category_name text not null, sort_order integer not null default 0,
 valid_from date not null, valid_until date,
 check(valid_until is null or valid_from < valid_until),
 foreign key(school_id,category_id) references public.daily_categories(school_id,id),
 exclude using gist(category_id with =,daterange(valid_from,valid_until,'[)') with &&)
);
create table if not exists public.daily_plans (
 id bigint generated always as identity primary key,
 school_id bigint not null references public.schools(id), plan_date date not null,
 title text, created_at timestamptz not null default now(), unique(school_id,plan_date),unique(school_id,id)
);
create table if not exists public.daily_plan_items (
 id bigint generated always as identity primary key,
 school_id bigint not null,plan_id bigint not null,
 category_version_id bigint not null references public.daily_category_versions(id),
 title text,content text not null,sort_order integer not null default 0,
 foreign key(school_id,plan_id) references public.daily_plans(school_id,id)
);
create index if not exists booking_regular_lookup on public.booking_regular_schedules(school_id,resource_id,weekday);
create index if not exists booking_date_lookup on public.booking_reservations(school_id,reservation_date);
-- Browser clients cannot access tables directly. Express uses secret key and MUST authorize writes.
alter table public.schools enable row level security;
alter table public.profiles enable row level security;
alter table public.booking_types enable row level security;
alter table public.booking_resources enable row level security;
alter table public.booking_periods enable row level security;
alter table public.booking_regular_schedules enable row level security;
alter table public.booking_reservations enable row level security;
alter table public.daily_categories enable row level security;
alter table public.daily_category_versions enable row level security;
alter table public.daily_plans enable row level security;
alter table public.daily_plan_items enable row level security;
-- This scaffold deliberately defines no public insert/update/delete policies.
-- IMPORTANT: reservation vs regular schedule cross-table conflict must be checked
-- inside a serialised DB transaction/RPC BEFORE enabling reservation POST.

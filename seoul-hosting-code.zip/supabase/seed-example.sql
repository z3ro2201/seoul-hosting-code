-- Run after schema.sql. Example ONLY. Replace names and organization codes.
insert into public.schools (school_name,office_code,organization_code)
values ('샘플초등학교','B10','DEMO-SCHOOL-001') on conflict(organization_code) do nothing;
with s as (select id from public.schools where organization_code='DEMO-SCHOOL-001')
insert into public.booking_types(school_id,name,sort_order)
select s.id,v.name,v.ord from s cross join (values ('체육시설예약',1),('태블릿예약',2)) v(name,ord)
on conflict(school_id,name) do nothing;
with s as (select id from public.schools where organization_code='DEMO-SCHOOL-001'),
 t as (select bt.id,bt.school_id from public.booking_types bt join s on s.id=bt.school_id where bt.name='체육시설예약')
insert into public.booking_resources(school_id,type_id,name,sort_order)
select t.school_id,t.id,v.name,v.ord from t cross join (values ('운동장',1),('체육관',2),('6층 강당',3),('4층 튼튼교실',4)) v(name,ord)
on conflict(school_id,type_id,name) do nothing;
with s as (select id from public.schools where organization_code='DEMO-SCHOOL-001')
insert into public.booking_periods(school_id,label,start_time,end_time,sort_order)
select s.id,v.label,v.start_time::time,v.end_time::time,v.ord from s cross join (values
('1교시','09:00','09:40',1),('2교시','09:50','10:30',2),('3교시','10:40','11:20',3),('4교시','11:30','12:10',4),('5교시','13:00','13:40',5),('6교시','13:50','14:30',6),('7교시','14:40','15:20',7)) v(label,start_time,end_time,ord)
where not exists(select 1 from public.booking_periods p where p.school_id=s.id and p.label=v.label);
-- Add regular assignments from the admin interface/API after authorization is built.

export default function AdminLogin() {
  return <section className="admin-login-page"><div className="admin-login-box"><span className="admin-login-logo">S</span><h1>관리자 로그인</h1><p>인증 기능을 연결하기 위한 페이지입니다.</p><div className="admin-empty" role="status">로그인 API 및 세션 인증 구현 전</div></div></section>;
}
